from flask import Flask, request, render_template, redirect, make_response
import jwt
import time
import os
import base64
import json

app = Flask(__name__)

SECRET_KEY = os.environ.get('JWT_SECRET', 'rookie-dev-secret')
FLAG = os.environ.get('FLAG', 'FLAG{not_configured}')

def parse_jwt(token):
    header_b64, payload_b64, *_ = token.split('.')
    padded_header = header_b64 + '=' * (-len(header_b64) % 4)
    header = json.loads(base64.urlsafe_b64decode(padded_header))
    alg = header.get('alg', 'HS256')

    # Intentionally vulnerable: unsigned JWTs are trusted.
    if alg == 'none':
        padded_payload = payload_b64 + '=' * (-len(payload_b64) % 4)
        return json.loads(base64.urlsafe_b64decode(padded_payload))
    return jwt.decode(token, SECRET_KEY, algorithms=[alg])

@app.route('/', methods=['GET', 'POST'])
def index():
    token = request.cookies.get('token')
    if token:
        try:
            payload = parse_jwt(token)
            if payload.get('admin'):
                return render_template('welcome.html', title='Welcome admin!', message='Administrative secret:', flag=FLAG, token=token)
            return render_template('welcome.html', title='Welcome!', message='Your account is not an administrator.', flag=None, token=token)
        except Exception:
            return render_template('welcome.html', title='Invalid token', message='The session token could not be processed.', flag=None, token=token)

    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        if username == 'testuser' and password == 'test123123':
            payload = {'username': username, 'admin': False, 'iat': int(time.time())}
            token = jwt.encode(payload, SECRET_KEY, algorithm='HS256')
            resp = make_response(redirect('/'))
            resp.set_cookie('token', token, httponly=False, samesite='Lax')
            return resp
        return render_template('index.html', error='Wrong username or password.')

    return render_template('index.html', error=None)

@app.route('/logout')
def logout():
    resp = make_response(redirect('/'))
    resp.delete_cookie('token')
    return resp

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3334)
