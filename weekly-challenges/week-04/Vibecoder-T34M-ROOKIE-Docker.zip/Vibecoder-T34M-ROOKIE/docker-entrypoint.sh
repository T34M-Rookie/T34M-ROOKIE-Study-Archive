#!/bin/sh
set -eu
FLAG_VALUE="$(python - <<'PYFLAG'
import os
k=bytes.fromhex(os.environ['FLAG_XOR_KEY_HEX'])
c=bytes.fromhex(os.environ['FLAG_XOR_CIPHER_HEX'])
if len(k)!=len(c): raise SystemExit('invalid flag material')
print(bytes(a^b for a,b in zip(k,c)).decode(), end='')
PYFLAG
)"
export FLAG="$FLAG_VALUE"
unset FLAG_VALUE
exec "$@"
