# Vibecoder

Welcome CTF 2025의 `vibecoder`를 바탕으로 구성한 4주차 입문 Web 문제입니다.

## 실행

```powershell
docker compose up --build
```

접속: `http://localhost:1340`

테스트 계정: `testuser / test123123`

## 종료

```powershell
docker compose down
```

플래그 형식: `FLAG{T34M_ROOKIE_...}`

의도적으로 취약한 로컬 CTF 서비스입니다. 인터넷에 직접 노출하지 마세요.
