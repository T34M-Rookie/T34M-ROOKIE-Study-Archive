# This is just one of those classic web challenges

Welcome CTF 2025의 PHP/SQLite 문제를 바탕으로 구성한 4주차 Web 문제입니다.

## 실행

```powershell
docker compose up --build
```

접속: `http://localhost:1341`

## 종료

```powershell
docker compose down
```

플래그 형식: `FLAG{T34M_ROOKIE_...}`

의도적으로 취약한 로컬 CTF 서비스입니다. 인터넷에 직접 노출하지 마세요.
