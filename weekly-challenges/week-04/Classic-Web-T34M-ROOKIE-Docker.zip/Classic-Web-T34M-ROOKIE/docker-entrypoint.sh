#!/bin/sh
set -eu
FLAG_VALUE="$(php -r '$k=hex2bin(getenv("FLAG_XOR_KEY_HEX"));$c=hex2bin(getenv("FLAG_XOR_CIPHER_HEX"));if($k===false||$c===false||strlen($k)!==strlen($c)){exit(1);}echo $k^$c;')"
export FLAG="$FLAG_VALUE"
rm -f /var/www/html/app.db
php /var/www/html/setup.php
chown www-data:www-data /var/www/html/app.db
chmod 0660 /var/www/html/app.db
unset FLAG FLAG_VALUE
exec docker-php-entrypoint "$@"
