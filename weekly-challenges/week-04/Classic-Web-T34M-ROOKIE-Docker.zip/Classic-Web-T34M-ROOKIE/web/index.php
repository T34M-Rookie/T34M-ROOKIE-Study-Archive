<?php
session_start();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    include __DIR__ . '/profile.php';
} else {
    $db = new SQLite3(__DIR__ . '/app.db');
    $result = $db->query("SELECT name, price FROM products WHERE category='electronics' LIMIT 10");
    $products=[]; while($row=$result->fetchArray(SQLITE3_ASSOC)){ $products[]=$row; } $db->close();
}
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Classic Shop</title>
<style>body{font-family:system-ui;background:#f4f6fa;color:#182033;margin:0}.wrap{max-width:1000px;margin:40px auto;padding:20px}.grid{display:grid;grid-template-columns:360px 1fr;gap:24px}.card{background:white;padding:22px;border-radius:14px;box-shadow:0 8px 30px #20305018}label{display:block;margin-top:10px;font-size:.9rem}input,textarea,select{width:100%;box-sizing:border-box;padding:9px;margin-top:4px}button{margin-top:14px;padding:10px 16px}.product{display:flex;justify-content:space-between;border-bottom:1px solid #e6e9ef;padding:12px 0}.muted{color:#68748a}@media(max-width:760px){.grid{grid-template-columns:1fr}}</style></head><body><div class="wrap"><h1>Classic Web Shop</h1><p class="muted">Update your profile and browse products selected for you.</p><div class="grid"><section class="card"><h2>Profile</h2><form method="post"><label>Email<input name="email" value="<?=h($_SESSION['email']??'user@example.com')?>"></label><label>Display name<input name="name" value="<?=h($_SESSION['name']??'rookie')?>"></label><label>Age<input name="age" type="number" value="<?=h($_SESSION['age']??20)?>"></label><label>Location<input name="location" value="<?=h($_SESSION['location']??'Seoul')?>"></label><label>Bio<textarea name="bio"><?=h($_SESSION['bio']??'Just a regular user')?></textarea></label><label>Newsletter<select name="newsletter"><option value="weekly">Weekly</option><option value="none">None</option></select></label><label>Product category<select name="category"><option value="popular">Popular</option><option value="trending">Trending</option><option value="other">Other</option></select></label><button>Save profile</button></form></section><section class="card"><h2>Recommended products</h2><?php foreach($products as $p): ?><div class="product"><span><?=h($p['name']??'')?></span><span><?=h($p['price']??'')?></span></div><?php endforeach; ?></section></div></div></body></html>
