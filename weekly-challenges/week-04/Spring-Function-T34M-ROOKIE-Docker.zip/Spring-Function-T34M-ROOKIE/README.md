# Spring Function

Spring Cloud Function 3.2.2의 routing 기능을 사용하는 4주차 CVE 실습 문제입니다.

## 실행

```powershell
docker compose up --build
```

접속: `http://localhost:1342`

## 종료

```powershell
docker compose down
```

플래그 형식: `FLAG{T34M_ROOKIE_...}`

이 서비스는 CVE-2022-22963 학습을 위해 의도적으로 취약한 버전을 사용합니다. 반드시 로컬에서만 실행하세요.
