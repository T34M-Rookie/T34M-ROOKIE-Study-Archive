package rookie.function;

import java.util.function.Function;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CtfApplication {
    public static void main(String[] args) { SpringApplication.run(CtfApplication.class, args); }
    @Bean public Function<String, String> echo() { return value -> "echo: " + value; }
    @Bean public Function<String, String> lowercase() { return value -> value == null ? "" : value.toLowerCase(); }
}
