package rookie.function;

import java.util.function.Function;
import org.springframework.cloud.function.context.FunctionCatalog;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RouteController {
    private final FunctionCatalog catalog;
    public RouteController(FunctionCatalog catalog) { this.catalog = catalog; }

    @SuppressWarnings("unchecked")
    @PostMapping("/api/route")
    public ResponseEntity<String> route(
        @RequestHeader(value="spring.cloud.function.routing-expression", required=false) String expression,
        @RequestBody(required=false) String body) {
        String routingExpression = (expression == null || expression.isBlank()) ? "'echo'" : expression;
        Function<Object,Object> router = catalog.lookup("functionRouter");
        if (router == null) return ResponseEntity.internalServerError().body("router unavailable");
        Message<String> message = MessageBuilder.withPayload(body == null ? "" : body)
            .setHeader("spring.cloud.function.routing-expression", routingExpression).build();
        try {
            Object result = router.apply(message);
            return ResponseEntity.ok(String.valueOf(result));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
