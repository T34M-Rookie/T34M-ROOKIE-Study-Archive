package rookie.function;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class FlagBootstrap implements CommandLineRunner {
    private static byte[] hex(String s) {
        if (s == null || (s.length() & 1) != 0) throw new IllegalArgumentException("bad flag material");
        byte[] out = new byte[s.length()/2];
        for (int i=0;i<out.length;i++) out[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);
        return out;
    }
    @Override public void run(String... args) throws Exception {
        byte[] k=hex(System.getenv("FLAG_XOR_KEY_HEX"));
        byte[] c=hex(System.getenv("FLAG_XOR_CIPHER_HEX"));
        if(k.length!=c.length) throw new IllegalStateException("invalid flag material");
        byte[] p=new byte[k.length]; for(int i=0;i<p.length;i++) p[i]=(byte)(k[i]^c[i]);
        Files.writeString(Path.of("/flag"), new String(p, StandardCharsets.UTF_8), StandardCharsets.UTF_8);
    }
}
