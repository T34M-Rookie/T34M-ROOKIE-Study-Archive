#!/bin/sh
set -eu

python3 - <<'PY'
import os
from pathlib import Path

key = bytes.fromhex(os.environ['FLAG_XOR_KEY_HEX'])
data = bytes.fromhex(os.environ['FLAG_XOR_DATA_HEX'])
if len(key) != len(data):
    raise SystemExit('invalid embedded flag data')

flag = bytes(a ^ b for a, b in zip(key, data))
Path('/app/flag.txt').write_bytes(flag)
PY

mkdir -p /app/uploads
cd /app
exec python3 main.py
