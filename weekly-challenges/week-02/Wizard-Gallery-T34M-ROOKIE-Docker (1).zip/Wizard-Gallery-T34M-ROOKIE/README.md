# Wizard Gallery — T34M ROOKIE Docker

scriptCTF 2025의 Web 문제 `Wizard Gallery`를 로컬 학습용 Docker 환경으로 구성한 패키지입니다.

## 실행

```bash
docker compose up --build
```

브라우저에서 아래 주소로 접속합니다.

```text
http://localhost:1337
```

## 종료

```bash
docker compose down
```

## 문제 정보

- 분야: Web
- 난이도: 초급~중급
- 목표: 이미지 업로드 및 갤러리 처리 과정의 취약점을 분석해 플래그 획득
- 플래그 형식: `FLAG{T34M_ROOKIE_...}`

## 주의

의도적으로 취약한 CTF 서비스입니다. 인터넷에 직접 노출하지 말고 로컬 환경에서만 실행하세요.

원본 문제: scriptCTF 2025 — Wizard Gallery, author Ashray Shah.
