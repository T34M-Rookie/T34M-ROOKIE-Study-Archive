#!/bin/sh
set -eu

mkdir -p /app/static/uploads/secrets
: > /app/static/uploads/secrets/secret_cookie.txt

if [ "${FLAG+x}" = "x" ]; then
    printf '%s' "$FLAG" > /app/flag.txt
fi

exec "$@"
