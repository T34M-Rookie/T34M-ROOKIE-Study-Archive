# Renderer Docker 실행

## 빠른 실행

```bash
docker compose up --build
```

접속 주소: `http://localhost:1337`

## 플래그 변경

`compose.yaml`의 `FLAG` 값을 수정하거나 다음처럼 실행합니다.

```bash
docker build -t ctf-renderer .
docker run --rm -p 127.0.0.1:1337:1337 -e 'FLAG=CTF{your_flag_here}' ctf-renderer
```

## 종료

```bash
docker compose down
```

이 Docker 설정은 문제의 파일 업로드 및 정적 파일 동작을 그대로 유지합니다. Flask 디버거는 사용하지 않고 Gunicorn 단일 워커로 실행합니다.

