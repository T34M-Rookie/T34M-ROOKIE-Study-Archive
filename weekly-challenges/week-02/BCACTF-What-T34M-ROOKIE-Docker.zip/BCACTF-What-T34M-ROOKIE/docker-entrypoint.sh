#!/bin/sh
set -eu

FLAG_PATH="/var/www/html/flag.txt"

php -r '
$key = hex2bin(getenv("FLAG_XOR_KEY_HEX"));
$cipher = hex2bin(getenv("FLAG_XOR_CIPHER_HEX"));
if ($key === false || $cipher === false || strlen($key) !== strlen($cipher)) {
    fwrite(STDERR, "Invalid embedded flag material.\n");
    exit(1);
}
$plain = $cipher ^ $key;
if (file_put_contents(getenv("FLAG_OUTPUT_PATH"), $plain) === false) {
    fwrite(STDERR, "Unable to create runtime flag file.\n");
    exit(1);
}
'

chmod 0444 "$FLAG_PATH"
exec docker-php-entrypoint "$@"
