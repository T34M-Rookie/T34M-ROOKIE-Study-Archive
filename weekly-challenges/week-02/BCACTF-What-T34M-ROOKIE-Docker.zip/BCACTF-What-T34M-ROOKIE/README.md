# What?

BCACTF 2025의 웹 문제 `What`을 로컬 Docker 환경에서 실행하기 위한 패키지입니다.

## 실행

```powershell
cd BCACTF-What-T34M-ROOKIE
docker compose up --build
```

브라우저에서 다음 주소로 접속합니다.

```text
http://localhost:1337
```

## 종료

```powershell
docker compose down
```

## 문제 설명

서로 다른 두 문자열을 입력해 서버의 검증을 통과하세요.

## 구성

- `index.php`: 원본 애플리케이션 로직
- `Dockerfile`: PHP-Apache 이미지 및 런타임 플래그 복원 설정
- `docker-entrypoint.sh`: 컨테이너 시작 시 플래그 파일 생성 후 공식 PHP 엔트리포인트 실행
- `compose.yaml`: 로컬 전용 포트 설정
- `flag.txt`: 빌드 컨텍스트용 빈 파일이며 실제 값은 런타임에 생성됨

이 서비스는 의도적으로 취약한 CTF 문제입니다. 인터넷에 직접 노출하지 마세요.
