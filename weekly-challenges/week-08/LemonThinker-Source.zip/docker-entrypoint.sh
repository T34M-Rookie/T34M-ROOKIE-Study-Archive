#!/bin/sh
set -eu
printf '%s\n' "${T34M_FLAG:-FLAG{LOCAL_PRACTICE_ONLY}}" > /flag.txt
exec /app/start.sh
