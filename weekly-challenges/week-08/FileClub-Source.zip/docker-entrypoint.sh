#!/bin/sh
set -eu
printf '%s\n' "${T34M_FLAG:-FLAG{LOCAL_PRACTICE_ONLY}}" > /flag.txt
export FLASK_APP=app
exec python -m flask run --host=0.0.0.0 --port=5000
