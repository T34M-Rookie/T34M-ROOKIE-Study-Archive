#!/bin/sh
set -eu
export FLAG="${T34M_FLAG:-FLAG{LOCAL_PRACTICE_ONLY}}"
exec node /app/index.js
