#!/bin/sh
set -eu
cd /ctf
printf '%s\n' "${T34M_FLAG:-FLAG{LOCAL_PRACTICE_ONLY}}" > flag.txt
python3 -c 'import secrets; print(secrets.token_hex(32))' > secret.txt
node admin_bot.js &
python3 server.py &
exec nginx -g 'daemon off;'
