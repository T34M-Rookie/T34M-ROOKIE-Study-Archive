#!/usr/bin/env python3
import os
import secrets

key = bytes.fromhex(os.environ.pop("FLAG_KEY_HEX"))
data = bytes.fromhex(os.environ.pop("FLAG_DATA_HEX"))
flag = bytes(a ^ b for a, b in zip(key, data))

with open("/app/flag.txt", "wb") as f:
    f.write(flag + b"\n")
os.chmod("/app/flag.txt", 0o444)

# The original challenge expects these to be secret but shared with bot.py
# through the process environment.
os.environ["ADMIN_PASS"] = secrets.token_urlsafe(32)
os.environ["SECRET"] = secrets.token_hex(32)

os.execvp("python3", ["python3", "app.py"])
