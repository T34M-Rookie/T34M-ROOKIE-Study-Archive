#!/usr/bin/env python3
import os
import secrets


def recover_flag() -> bytes:
    key = bytes.fromhex(os.environ["FLAG_KEY_HEX"])
    data = bytes.fromhex(os.environ["FLAG_DATA_HEX"])
    if len(key) != len(data):
        raise RuntimeError("invalid flag material")
    return bytes(a ^ b for a, b in zip(key, data))


os.chdir("/app")
with open("/app/flag.txt", "wb") as fp:
    fp.write(recover_flag())
os.chmod("/app/flag.txt", 0o444)

# Keep the original app/bot behavior while avoiding the archive's default secrets.
os.environ.setdefault("ADMIN_PASS", secrets.token_urlsafe(32))
os.environ.setdefault("SECRET", secrets.token_hex(32))

try:
    os.unlink("/tmp/database.db")
except FileNotFoundError:
    pass

os.execvpe("python3", ["python3", "app.py"], os.environ)
