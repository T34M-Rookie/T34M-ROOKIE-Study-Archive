# Fancy Notes — T34M ROOKIE Docker Package

- Original challenge: **Fancy Notes**, idekCTF 2021
- Category: Web
- Local URL: `http://localhost:1353`
- Flag format: `FLAG{T34M_ROOKIE_...}`

## Run

```bash
docker compose up --build
```

Open `http://localhost:1353` in a browser.

The challenge includes the original admin report bot. If you need the bot to reach a service running on the Docker host, `host.docker.internal` is mapped for the container.

## Stop

```bash
docker compose down
```

## Package layout

The original challenge application is included directly in this package. No Git clone is performed while building or running the container.

- `Dockerfile` — original challenge Dockerfile
- `app.py`, `bot.js`, `templates/`, `static/js/` — original challenge source
- `Dockerfile.t34m` — deployment wrapper for a current Debian/Python/Chromium environment
- `docker-entrypoint.py` — reconstructs the study flag at container startup and initializes runtime secrets
- `compose.yaml` — localhost-only deployment

The first build requires Internet access for the base image and Debian/Python/npm packages. The original frontend also references external CSS/JavaScript resources.

> This intentionally vulnerable service is bound to `127.0.0.1`. Do not expose it directly to an untrusted network.
