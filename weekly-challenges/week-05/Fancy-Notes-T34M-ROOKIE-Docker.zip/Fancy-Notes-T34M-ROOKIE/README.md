# fancy-notes — idekCTF 2021

원본: `sajjadium/ctf-archives/ctfs/idekCTF/2021/web/fancy-notes`

문제 로직은 재작성하지 않습니다. Docker 빌드 시 ctf-archives의 고정 커밋
`0c701f9ba89e78aa151cde0cc61fd9c8639f5d3d`에서 원본 문제 디렉터리를 가져옵니다.

원본 `app.py`, 템플릿, 정적 파일, `bot.js`를 그대로 사용합니다.
변경점은 배포 안정성을 위한 최신 Chromium/Python 기반 Docker 래퍼와
T34M ROOKIE 플래그 런타임 복원뿐입니다.

## 실행
```bash
docker compose up --build
```

접속: http://localhost:1350

## 종료
```bash
docker compose down
```

로컬 실습 전용입니다. 외부에 노출하지 마세요.
