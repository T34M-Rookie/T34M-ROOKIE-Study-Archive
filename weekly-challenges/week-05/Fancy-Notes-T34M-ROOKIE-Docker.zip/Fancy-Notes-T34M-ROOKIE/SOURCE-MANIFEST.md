# Source manifest

Source archive:

- Repository: `sajjadium/ctf-archives`
- Commit: `0c701f9ba89e78aa151cde0cc61fd9c8639f5d3d`
- Path: `ctfs/idekCTF/2021/web/fancy-notes`
- Organizer mirror: `idekctf/idekctf-2021`, `web/FancyNotes/dist/challenge`

Original Git blob SHAs preserved byte-for-byte:

- `Dockerfile` — `a6692c4cfa2d63ad01642f914f70532dba434dec`
- `app.py` — `0dc93b27d57b06ac23b1f27b7dc1c4ddd4654b6b`
- `bot.js` — `1fca6784f3aa270dc5177f22832f3f44b9078711`
- `templates/create.html` — `8ab7fa1c78b948f28b39da0361adbd2f0becd306`
- `templates/fancy.html` — `f47146d869bb67e6f1fabc8dd023e961bc171170`
- `templates/index.html` — `781c036ca5d348ffbd54a19fd196e7a1bb5ac288`
- `templates/layout.html` — `271a3e2c1e00282fce8a724e41d603c75820334b`
- `templates/login.html` — `e72a596b77ae6ebc6812e8f6f7c3b71e9091f62a`
- `templates/register.html` — `f79f0f36d523a3575c7b6b9d5747db8ced427590`
- `templates/report.html` — `19065ebe4de8d3d1c273d17a0be0897f50379177`
- `static/js/fancify.js` — `bc0724c2f1690d840e5ed9788e9a498b099be9fb`
- `static/js/styles.js` — `7982cfa41bc73f27ba0a10c8eff246c9408408a2`

Intentional deployment changes:

- Original `flag.txt` content is not distributed. The packaged file is empty and is replaced at startup using XOR-obfuscated flag material.
- `static/images/success.png` is a compatible local placeholder. Its original blob is `0d66519fc6cfae8715e4a5a0bcb19d7fc9c7c591`; the connector available in this environment exposes repository binaries only through a truncated base64 response, so that one cosmetic asset could not be reproduced byte-for-byte.
- `Dockerfile.t34m`, `docker-entrypoint.py`, `compose.yaml`, `.dockerignore`, and this documentation are T34M deployment files and are not part of the original challenge.
