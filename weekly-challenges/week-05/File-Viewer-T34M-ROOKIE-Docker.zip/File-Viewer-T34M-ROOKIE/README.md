# file_viewer — Lexington Informatics Tournament CTF 2025

원본: `sajjadium/ctf-archives/ctfs/LexingtonInformaticsTournament/2025/web/file_viewer`

원본 `app.py`를 변경하지 않고 사용합니다.
아카이브에 별도 Dockerfile이 없어 Docker 배포 래퍼와 샘플 파일, T34M ROOKIE용 플래그 처리만 추가했습니다.

## 실행

```bash
docker compose up --build
```

접속: http://localhost:1351

## 종료

```bash
docker compose down
```

로컬 실습 전용입니다. 인터넷에 노출하지 마세요.
