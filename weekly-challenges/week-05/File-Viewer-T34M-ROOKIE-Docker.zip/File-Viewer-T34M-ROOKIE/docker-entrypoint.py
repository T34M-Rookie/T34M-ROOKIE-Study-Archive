#!/usr/bin/env python3
import os, pwd

KEY = bytes.fromhex("6150e4814843c0f98c763d922eace34bc7d82281a5d3c7e09dd85d2eca")
DATA = bytes.fromhex("271ca5c63317f3cdc1296fdd61e7aa0e989e6bcde08c91a9d88f187cb7")
flag = bytes(a ^ b for a, b in zip(KEY, DATA))
with open("/app/flag", "wb") as f:
    f.write(flag + b"\n")
os.chmod("/app/flag", 0o444)

u = pwd.getpwnam("ctf")
os.setgid(u.pw_gid)
os.setuid(u.pw_uid)
os.execvp("python3", ["python3", "app.py"])
