#!/usr/bin/env python3
import os, pwd

KEY = bytes.fromhex("7cf6d07c37a8ff8ee7da76997730869e3b0e5ebc0d0048781c4927f50e8e")
DATA = bytes.fromhex("3aba913b4cfcccbaaa8524d6387bcfdb644c1ffe545f0231520366bc42f3")
flag = bytes(a ^ b for a, b in zip(KEY, DATA))
with open("/app/flag", "wb") as f:
    f.write(flag + b"\n")
os.chmod("/app/flag", 0o444)

u = pwd.getpwnam("ctf")
os.setgid(u.pw_gid)
os.setuid(u.pw_uid)
os.execvp("python3", ["python3", "app.py"])
