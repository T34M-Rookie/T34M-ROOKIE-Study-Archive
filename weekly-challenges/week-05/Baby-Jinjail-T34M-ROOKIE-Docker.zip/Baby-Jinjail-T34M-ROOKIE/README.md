# baby-jinjail — idekCTF 2021

원본: `sajjadium/ctf-archives/ctfs/idekCTF/2021/web/baby-jinjail`

원본 `app.py`와 `templates/layout.html`을 변경하지 않고 사용합니다.
Docker 배포 래퍼와 T34M ROOKIE용 플래그 처리만 추가했습니다.

## 실행

```bash
docker compose up --build
```

접속: http://localhost:1350

## 종료

```bash
docker compose down
```

로컬 실습 전용입니다. 인터넷에 노출하지 마세요.
