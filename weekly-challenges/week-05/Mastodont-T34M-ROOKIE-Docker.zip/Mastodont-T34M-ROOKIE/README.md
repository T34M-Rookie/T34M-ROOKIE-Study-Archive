# Mastodon't — Hack.lu CTF 2023

원본: `sajjadium/ctf-archives/ctfs/Hack.lu/2023/web/Mastodont`

이 패키지는 문제 로직을 재작성하지 않습니다.
Docker 빌드 시 `sajjadium/ctf-archives`의 고정 커밋에서 원본 Mastodon't 소스 트리를 sparse checkout하여 사용합니다.

- Archive commit: `0c701f9ba89e78aa151cde0cc61fd9c8639f5d3d`
- Vulnerable Mastodon commit specified by the challenge: `3d8bd093b9197659563070d2c763988428063406`
- CVE: `CVE-2023-36460`
- Original local login: `pwn@mastodont.flu.xxx` / `hacklu23`

원본 Dockerfile의 challenge-specific ImageMagick 빌드, setuid `readflag`, s6 초기화 구조를 유지합니다.
달라진 부분은 로컬 포트, T34M ROOKIE 플래그 난독화, 현재 Debian에서 실패할 수 있는 cleanup 단계뿐입니다.

## hosts 설정

Windows의 아래 파일을 관리자 권한으로 수정합니다.

`C:\Windows\System32\drivers\etc\hosts`

추가:

```text
127.0.0.1 mastodon.local
```

## 실행

```bash
docker compose up --build
```

접속: `https://mastodon.local:1352`

Traefik 기본 인증서 경고가 표시될 수 있습니다.

## 종료

```bash
docker compose down
```

데이터까지 초기화:

```bash
docker compose down -v
```

이 문제는 실제 Mastodon/Ruby/Node/ImageMagick 소스를 빌드하므로 다른 두 문제보다 빌드가 훨씬 무겁고 인터넷 연결이 필요합니다.
로컬 실습 전용이며 인터넷에 노출하지 마세요.
