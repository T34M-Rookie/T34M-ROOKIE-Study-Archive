package id.compfest.ctf.log4baby;

import javax.servlet.http.HttpServletRequest;

public class Utils {
    public String getBrowserName(HttpServletRequest request) {
        String ua = request.getHeader("User-Agent");
        return ua == null ? "unknown" : ua;
    }
}
