#!/bin/sh
set -eu
SECRET="$(python3 - <<'PY'
import os
k=bytes.fromhex(os.environ['FLAG_XOR_KEY_HEX'])
d=bytes.fromhex(os.environ['FLAG_XOR_DATA_HEX'])
if len(k)!=len(d): raise SystemExit('invalid embedded flag data')
print(bytes(a^b for a,b in zip(k,d)).decode(), end='')
PY
)"
export SECRET
exec java -jar /app/log4baby.jar
