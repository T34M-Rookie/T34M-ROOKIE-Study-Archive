# Log4baby — T34M ROOKIE Docker

COMPFEST 2022의 Web 문제 `Log4baby`를 로컬 학습용 Docker 환경으로 구성한 패키지입니다.

## 실행

```bash
docker compose up --build
```

접속 주소:

```text
http://localhost:1338
```

## 종료

```bash
docker compose down
```

## 문제 정보

- 분야: Web
- 난이도: 초급~중급
- 주요 구성: Spring Boot, Log4j Core 2.14.1
- 목표: 요청 처리와 로깅 동작을 분석해 플래그 획득
- 플래그 형식: `FLAG{T34M_ROOKIE_...}`

## 주의

의도적으로 취약한 Log4j 버전을 포함한 CTF 서비스입니다. 인터넷에 직접 노출하지 말고 로컬 격리 환경에서만 실행하세요.

원본 문제: COMPFEST 2022 — Log4baby.
