# CandyCrash — T34M ROOKIE Docker

m0leCon 2026 Beginner의 Web 문제 `CandyCrash`를 로컬 학습용 Docker 환경으로 구성한 패키지입니다.
원본 아카이브에 프론트엔드 파일이 보존되어 있지 않아, 8×8 매치-3 게임과 리플레이 기능을 사용할 수 있는 학습용 프론트엔드를 복원했습니다. 가로/세로 3개 이상이 맞으면 제거되고, 위 캔디가 내려온 뒤 새 캔디가 채워지며 연쇄 매치도 처리됩니다. 취약한 백엔드 API와 VM 디버그 로직은 유지했습니다.

## 실행

```bash
docker compose up --build
```

접속 주소:

```text
http://localhost:1337
```

## 종료

```bash
docker compose down
```

## 문제 정보

- 분야: Web
- 난이도: 초급
- 목표: 게임 서버의 API와 디버그 기능을 분석해 플래그 획득
- 플래그 형식: `FLAG{T34M_ROOKIE_...}`

## 주의

의도적으로 취약한 CTF 서비스입니다. 인터넷에 직접 노출하지 말고 로컬 환경에서만 실행하세요.

원본 문제: m0leCon 2026 Beginner — CandyCrash.
