#!/bin/sh
set -eu
node - <<'NODE'
const fs = require('fs');
const key = Buffer.from(process.env.FLAG_XOR_KEY_HEX, 'hex');
const data = Buffer.from(process.env.FLAG_XOR_DATA_HEX, 'hex');
if (key.length !== data.length) throw new Error('invalid embedded flag data');
const out = Buffer.alloc(key.length);
for (let i = 0; i < key.length; i++) out[i] = key[i] ^ data[i];
fs.writeFileSync('/app/FLAG', out);
NODE
cd /app
exec node CandyCrash.js
