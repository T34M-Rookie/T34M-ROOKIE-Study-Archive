(() => {
  const Engine = window.CandyEngine;
  const boardEl = document.querySelector('#board');
  const sessionEl = document.querySelector('#sessionId');
  const moveCountEl = document.querySelector('#moveCount');
  const scoreEl = document.querySelector('#verifiedScore');
  const targetEl = document.querySelector('#targetScore');
  const messageEl = document.querySelector('#message');
  const remainingEl = document.querySelector('#remaining');
  const progressEl = document.querySelector('#progressBar');
  const submitButton = document.querySelector('#submitRun');
  const newGameButton = document.querySelector('#newGame');
  const replayList = document.querySelector('#replayList');
  const replayView = document.querySelector('#replayView');
  const healthDot = document.querySelector('#healthDot');
  const healthText = document.querySelector('#healthText');

  let sessionId = null;
  let targetScore = 10000;
  let board = [];
  let moves = [];
  let selected = null;
  let rng = null;
  let runScore = 0;
  let animating = false;

  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  function setMessage(text, type = '') {
    messageEl.textContent = text;
    messageEl.className = `message ${type}`.trim();
  }

  function updateScore() {
    scoreEl.textContent = runScore.toLocaleString();
    const pct = Math.max(0, Math.min(100, (runScore / targetScore) * 100));
    progressEl.style.width = `${pct}%`;
  }

  function renderBoard() {
    boardEl.innerHTML = '';
    board.forEach((kind, index) => {
      const button = document.createElement('button');
      const empty = kind === null || kind === undefined;
      button.className = 'candy' + (selected === index ? ' selected' : '') + (empty ? ' empty' : '');
      if (!empty) button.dataset.kind = String(kind);
      button.title = empty ? 'Empty' : `Candy ${index + 1}`;
      button.disabled = empty || animating;
      button.addEventListener('click', () => selectCandy(index));
      boardEl.appendChild(button);
    });
  }

  function highlightMatches(matches) {
    for (const index of matches) {
      const el = boardEl.children[index];
      if (el) el.classList.add('matched');
    }
  }

  async function resolveBoard(matches) {
    let cascade = 0;
    let gained = 0;

    while (matches.size && cascade < Engine.MAX_CASCADES) {
      cascade++;
      const count = matches.size;
      const delta = count * 100 * cascade;
      gained += delta;
      runScore += delta;
      updateScore();

      highlightMatches(matches);
      setMessage(cascade === 1
        ? `${count} candies matched! +${delta.toLocaleString()} points.`
        : `Cascade x${cascade}! ${count} more candies cleared. +${delta.toLocaleString()} points.`, 'success');
      await sleep(220);

      Engine.clearMatches(board, matches);
      renderBoard();
      await sleep(130);

      Engine.collapseAndRefill(board, rng);
      renderBoard();
      await sleep(180);

      matches = Engine.findMatches(board);
    }

    return gained;
  }

  async function selectCandy(index) {
    if (!sessionId || animating) return;

    if (selected === null) {
      selected = index;
      renderBoard();
      return;
    }

    if (selected === index) {
      selected = null;
      renderBoard();
      return;
    }

    const from = selected;
    const to = index;
    selected = null;

    if (!Engine.isAdjacent(from, to)) {
      setMessage('Only neighboring candies can be swapped.', 'error');
      renderBoard();
      return;
    }

    animating = true;
    Engine.swap(board, from, to);
    renderBoard();
    await sleep(140);

    let matches = Engine.findMatches(board);
    if (!matches.size) {
      Engine.swap(board, from, to);
      await sleep(100);
      animating = false;
      renderBoard();
      setMessage('That swap does not make a match. Try another move.');
      return;
    }

    moves.push({ from, to });
    moveCountEl.textContent = String(moves.length);
    await resolveBoard(matches);

    animating = false;
    renderBoard();
    submitButton.disabled = moves.length === 0;
    if (runScore >= targetScore) {
      setMessage('Target score reached locally. Submit the run for referee verification.', 'success');
    } else {
      setMessage(`Move accepted. Current run score: ${runScore.toLocaleString()}.`);
    }
  }

  async function startGame() {
    if (!Engine) throw new Error('Candy engine failed to load');
    animating = true;
    setMessage('Requesting a new referee session...');
    const response = await fetch('/api/session', { method: 'POST' });
    if (!response.ok) throw new Error('Could not start game');
    const data = await response.json();

    sessionId = data.sessionId;
    targetScore = data.targetScore;
    rng = Engine.createRng(data.seed);
    board = Engine.generateBoard(rng);
    moves = [];
    selected = null;
    runScore = 0;
    animating = false;

    sessionEl.textContent = sessionId;
    targetEl.textContent = targetScore.toLocaleString();
    moveCountEl.textContent = '0';
    updateScore();
    remainingEl.textContent = 'No run submitted yet.';
    submitButton.disabled = true;
    setMessage('Session ready. Make horizontal or vertical matches of 3 or more candies.');
    renderBoard();
  }

  async function submitRun() {
    if (!sessionId || animating) return;
    submitButton.disabled = true;
    setMessage('Referee is replaying your moves...');
    const response = await fetch('/api/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId, moves })
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error || 'Submission failed.', 'error');
      submitButton.disabled = false;
      return;
    }

    const verifiedScore = Number(data.score || 0);
    if (verifiedScore !== runScore) {
      setMessage(`Referee score mismatch: local ${runScore.toLocaleString()}, verified ${verifiedScore.toLocaleString()}.`, 'error');
      runScore = verifiedScore;
      updateScore();
    }

    if (data.verified) {
      setMessage(`Verified! ${data.flag}`, 'success');
      remainingEl.textContent = 'Target reached.';
    } else {
      setMessage('Run verified, but the target score was not reached.');
      remainingEl.textContent = `${Number(data.remaining).toLocaleString()} points remaining.`;
      submitButton.disabled = false;
    }
    refreshReplays();
  }

  async function refreshReplays() {
    try {
      const response = await fetch('/api/replays');
      const data = await response.json();
      replayList.innerHTML = '';
      const files = Array.isArray(data.files) ? data.files : [];
      if (!files.length) {
        replayList.innerHTML = '<li>No replay files yet.</li>';
        return;
      }
      files.slice(-8).reverse().forEach(({ name }) => {
        const li = document.createElement('li');
        const button = document.createElement('button');
        button.textContent = name;
        button.addEventListener('click', () => inspectReplay(name));
        li.appendChild(button);
        replayList.appendChild(li);
      });
    } catch (_) {
      replayList.innerHTML = '<li>Replay service unavailable.</li>';
    }
  }

  async function inspectReplay(name) {
    replayView.textContent = 'Loading replay...';
    const response = await fetch(`/api/replays?file=${encodeURIComponent(name)}`);
    replayView.textContent = response.ok ? await response.text() : 'Replay not found.';
  }

  async function healthCheck() {
    try {
      const response = await fetch('/api/health');
      if (!response.ok) throw new Error();
      healthDot.classList.add('ok');
      healthText.textContent = 'referee online';
    } catch (_) {
      healthDot.classList.remove('ok');
      healthText.textContent = 'referee offline';
    }
  }

  newGameButton.addEventListener('click', () => startGame().catch(err => {
    animating = false;
    setMessage(err.message, 'error');
  }));
  submitButton.addEventListener('click', () => submitRun().catch(err => {
    setMessage(err.message, 'error');
    submitButton.disabled = false;
  }));
  document.querySelector('#refreshReplays').addEventListener('click', refreshReplays);

  healthCheck();
  refreshReplays();
  startGame().catch(err => {
    animating = false;
    setMessage(err.message, 'error');
  });
})();
