(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.CandyEngine = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const WIDTH = 8;
  const HEIGHT = 8;
  const CANDY_TYPES = 6;
  const MAX_CASCADES = 32;

  function createRng(seed) {
    let state = (Number(seed) >>> 0) || 1;
    return function rng() {
      state ^= state << 13; state >>>= 0;
      state ^= state >>> 17; state >>>= 0;
      state ^= state << 5; state >>>= 0;
      return state / 0x100000000;
    };
  }

  function randomKind(rng, choices = null) {
    if (choices && choices.length) {
      return choices[Math.floor(rng() * choices.length)];
    }
    return Math.floor(rng() * CANDY_TYPES);
  }

  function generateBoard(rng) {
    const board = new Array(WIDTH * HEIGHT).fill(null);
    for (let row = 0; row < HEIGHT; row++) {
      for (let col = 0; col < WIDTH; col++) {
        const blocked = new Set();
        if (col >= 2) {
          const a = board[row * WIDTH + col - 1];
          const b = board[row * WIDTH + col - 2];
          if (a === b) blocked.add(a);
        }
        if (row >= 2) {
          const a = board[(row - 1) * WIDTH + col];
          const b = board[(row - 2) * WIDTH + col];
          if (a === b) blocked.add(a);
        }
        const choices = [];
        for (let kind = 0; kind < CANDY_TYPES; kind++) {
          if (!blocked.has(kind)) choices.push(kind);
        }
        board[row * WIDTH + col] = randomKind(rng, choices);
      }
    }
    return board;
  }

  function rowOf(index) {
    return Math.floor(index / WIDTH);
  }

  function colOf(index) {
    return index % WIDTH;
  }

  function isAdjacent(from, to) {
    if (!Number.isInteger(from) || !Number.isInteger(to)) return false;
    if (from < 0 || to < 0 || from >= WIDTH * HEIGHT || to >= WIDTH * HEIGHT) return false;
    const dr = Math.abs(rowOf(from) - rowOf(to));
    const dc = Math.abs(colOf(from) - colOf(to));
    return dr + dc === 1;
  }

  function swap(board, from, to) {
    const tmp = board[from];
    board[from] = board[to];
    board[to] = tmp;
  }

  function findMatches(board) {
    const matched = new Set();

    for (let row = 0; row < HEIGHT; row++) {
      let runStart = 0;
      while (runStart < WIDTH) {
        const startIndex = row * WIDTH + runStart;
        const kind = board[startIndex];
        if (kind === null || kind === undefined) {
          runStart++;
          continue;
        }
        let runEnd = runStart + 1;
        while (runEnd < WIDTH && board[row * WIDTH + runEnd] === kind) runEnd++;
        if (runEnd - runStart >= 3) {
          for (let col = runStart; col < runEnd; col++) matched.add(row * WIDTH + col);
        }
        runStart = runEnd;
      }
    }

    for (let col = 0; col < WIDTH; col++) {
      let runStart = 0;
      while (runStart < HEIGHT) {
        const startIndex = runStart * WIDTH + col;
        const kind = board[startIndex];
        if (kind === null || kind === undefined) {
          runStart++;
          continue;
        }
        let runEnd = runStart + 1;
        while (runEnd < HEIGHT && board[runEnd * WIDTH + col] === kind) runEnd++;
        if (runEnd - runStart >= 3) {
          for (let row = runStart; row < runEnd; row++) matched.add(row * WIDTH + col);
        }
        runStart = runEnd;
      }
    }

    return matched;
  }

  function clearMatches(board, matched) {
    for (const index of matched) board[index] = null;
    return matched.size;
  }

  function collapseAndRefill(board, rng) {
    for (let col = 0; col < WIDTH; col++) {
      let writeRow = HEIGHT - 1;
      for (let readRow = HEIGHT - 1; readRow >= 0; readRow--) {
        const value = board[readRow * WIDTH + col];
        if (value !== null && value !== undefined) {
          board[writeRow * WIDTH + col] = value;
          if (writeRow !== readRow) board[readRow * WIDTH + col] = null;
          writeRow--;
        }
      }
      while (writeRow >= 0) {
        board[writeRow * WIDTH + col] = randomKind(rng);
        writeRow--;
      }
    }
  }

  function attemptMove(board, from, to, rng) {
    if (!isAdjacent(from, to)) return { valid: false, score: 0, cascades: 0, cleared: 0 };

    swap(board, from, to);
    let matches = findMatches(board);
    if (!matches.size) {
      swap(board, from, to);
      return { valid: false, score: 0, cascades: 0, cleared: 0 };
    }

    let score = 0;
    let cascades = 0;
    let cleared = 0;

    while (matches.size && cascades < MAX_CASCADES) {
      cascades++;
      cleared += matches.size;
      score += matches.size * 100 * cascades;
      clearMatches(board, matches);
      collapseAndRefill(board, rng);
      matches = findMatches(board);
    }

    return { valid: true, score, cascades, cleared };
  }

  return {
    WIDTH,
    HEIGHT,
    CANDY_TYPES,
    MAX_CASCADES,
    createRng,
    generateBoard,
    isAdjacent,
    swap,
    findMatches,
    clearMatches,
    collapseAndRefill,
    attemptMove,
  };
});
