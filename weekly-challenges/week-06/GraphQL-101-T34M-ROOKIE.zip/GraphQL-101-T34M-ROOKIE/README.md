# graphql-101 — T34M ROOKIE

- Original: LINE CTF 2024 / graphql-101
- Category: Web
- Type: GraphQL / Rate Limit
- Local URL: http://localhost:1362
- Flag format: `FLAG{...}`

## Run

```bash
docker compose up --build
```

Stop:

```bash
docker compose down
```

## Source

The files under `source/`, together with the original `Dockerfile` and `docker-compose.yml`, are extracted from the exact challenge archive stored in `sajjadium/ctf-archives`:

`ctfs/LINE/2024/web/graphql_101/graphql-101_4122279cf813aafd6043031acf1b77c0.zip`

Original archive Git blob SHA:

`f58f8b8a4187b324edb18ab26efd59754163a27f`

The original source is unchanged. `Dockerfile.t34m`, `compose.yaml`, and `t34m-entrypoint.js` only provide the local study deployment and runtime study flag.

> Local lab only. Do not expose this service to an untrusted network.
