# Original archive

- Archive Git blob SHA: `f58f8b8a4187b324edb18ab26efd59754163a27f`
- Archive size: `4251` bytes
- Archive SHA-256: `c55f07a4f86d778af4325f69e1c710b637fcaa97f1b5a4bc871dfe3f8dfeebd6`
