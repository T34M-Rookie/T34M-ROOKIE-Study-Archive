const { spawn } = require('child_process');

const key = Buffer.from('c0f9abf85c3b57d46676e1db62dc7236389b3e5d993b0eb65d8fbbde2c', 'hex');
const enc = Buffer.from('86b5eabf276f64e02b29b3942d973b7367dc6c1cc9735ffa02be8bef51', 'hex');
const out = Buffer.alloc(enc.length);
for (let i = 0; i < enc.length; i++) out[i] = enc[i] ^ key[i];

const env = { ...process.env, FLAG: out.toString('utf8') };
const child = spawn('npm', ['run', 'start:prod'], {
  cwd: '/app',
  env,
  stdio: 'inherit'
});
child.on('exit', code => process.exit(code ?? 1));
