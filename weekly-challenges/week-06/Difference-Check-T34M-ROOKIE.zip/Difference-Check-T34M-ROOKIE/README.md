# difference-check — T34M ROOKIE

- Original: idekCTF 2021 / difference-check
- Category: Web
- Type: SSRF Filter Bypass
- Local URL: http://localhost:1361
- Flag format: `FLAG{...}`

## Run

```bash
docker compose up --build
```

Stop:

```bash
docker compose down
```

## Source

The challenge source is copied directly from `sajjadium/ctf-archives`:

`ctfs/idekCTF/2021/web/difference-check`

`index.js`, `package.json`, the Handlebars templates, and the original `Dockerfile` are preserved unchanged.
`Dockerfile.t34m` and `compose.yaml` are study deployment wrappers. At container startup, only the redacted flag placeholder in the container copy is replaced with the study flag.

> Local lab only. Do not expose this service to an untrusted network.
