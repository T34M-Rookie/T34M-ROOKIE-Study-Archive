# Original source blob SHAs

- `Dockerfile`: `b962c4288fcaa5c757faa319244fbf622de1494b`
- `index.js`: `857f6e0a08eb2a1152d4f09c8d7a894345a077d7`
- `package.json`: `2d411ed1a254b1d8b031a7390ef053eab27ef66d`
- `views/index.hbs`: `ef1e2cfffd3e1af9c5e1db2f5b394870a585ff1e`
- `views/diff.hbs`: `0aa124fedbce179d909f49b3fe391a2239d9c399`
- `views/layouts/main.hbs`: `ff3cf8129635f23fe3eaad881c52c0043ef9eae4`
