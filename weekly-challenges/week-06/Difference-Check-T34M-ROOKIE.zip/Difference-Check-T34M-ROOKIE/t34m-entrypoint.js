const fs = require('fs');
const { spawn } = require('child_process');

const key = Buffer.from('0e0414957d62e91e6c92132f0fca62dbf99a6bcf53a84cbbc8990e169944a40a198e', 'hex');
const enc = Buffer.from('484855d20636da2a21cd416040812b9ea6de228915ed1efe86da4b49da0ce14952f3', 'hex');
const out = Buffer.alloc(enc.length);
for (let i = 0; i < enc.length; i++) out[i] = enc[i] ^ key[i];
const flag = out.toString('utf8');

const path = '/app/index.js';
const original = fs.readFileSync(path, 'utf8');
if (!original.includes("idek{REDACTED}")) {
  console.error('expected original flag placeholder was not found');
  process.exit(1);
}
fs.writeFileSync(path, original.replace("idek{REDACTED}", flag));

const child = spawn('node', ['index.js'], {
  cwd: '/app',
  stdio: 'inherit'
});
child.on('exit', code => process.exit(code ?? 1));
