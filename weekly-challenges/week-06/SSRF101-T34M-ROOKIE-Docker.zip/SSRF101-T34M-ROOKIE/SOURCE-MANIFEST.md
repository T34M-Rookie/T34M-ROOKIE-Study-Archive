# Original source blob SHAs

- `Dockerfile`: `4fe22215ce5804c21b4cf540a36305202cb37c39`
- `docker-compose.yml`: `05d7b063f70003bb125c9db73910ee09907016ee`
- `flag.txt`: `13eb20a0684eaf75e870776bc63e6e42c357fd0d`
- `package.json`: `d44811503dc506dbdfc5557a5742ae9bc9b7aa41`
- `private1.js`: `b9ee5bef52e380525a2149cae784dd110ec3114c`
- `private2.js`: `2545a93fe2ce5a398102cd194344a2cd4740ec5a`
- `public.js`: `d77093c4c406fb83b4e9477577752dd499dad66d`
- `start.sh`: `f7e197473c9fccb84697820efdd2a0f53dbd5a4f`
- `package-lock.json`: `e13e6152c52b14fc6f400f93a5cc6ee2bef84104`


## UI adaptation

`public.original.js` preserves the original WolvCTF file. `public.js` only changes the `/` route to serve `index.html` and adds `/source`; the `/ssrf` handler is unchanged.
