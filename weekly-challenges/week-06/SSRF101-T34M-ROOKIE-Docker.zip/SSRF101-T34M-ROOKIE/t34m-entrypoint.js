const fs = require('fs');
const { spawn } = require('child_process');

const key = Buffer.from('d7cd7dd2c8cae02618120a0c9e860b93e075b645472c47c86e', 'hex');
const enc = Buffer.from('91813c95b39ed312554d5843d1cd42d6bf26e517011d77f913', 'hex');
const flag = Buffer.alloc(enc.length);
for (let i = 0; i < enc.length; i++) flag[i] = enc[i] ^ key[i];

fs.writeFileSync('/ctf/app/flag.txt', flag, { mode: 0o444 });

const child = spawn('/bin/bash', ['start.sh'], {
  cwd: '/ctf/app',
  stdio: 'inherit'
});
child.on('exit', code => process.exit(code ?? 1));
