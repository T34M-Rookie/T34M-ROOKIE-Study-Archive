# SSRF101 — T34M ROOKIE

- Original: WolvCTF 2022 / SSRF101
- Category: Web
- Type: SSRF
- Local URL: http://localhost:1360
- Flag format: `FLAG{...}`

## Run

```bash
docker compose up --build
```

Stop:

```bash
docker compose down
```

## Source

The challenge source files are copied directly from `sajjadium/ctf-archives`:

`ctfs/WolvCTF/2022/web/SSRF101`

The original `Dockerfile` and `docker-compose.yml` are preserved for reference.
For the study environment, use `compose.yaml`, which binds the service to `127.0.0.1` and uses `Dockerfile.t34m`.

T34M changes:
- Added a simple UI at `/`.
- The original `public.js` is preserved byte-for-byte as `public.original.js` and exposed at `/source`.
- The `/ssrf` challenge handler itself is unchanged.
- Local Docker wrapper and study flag injection were added.

> Local lab only. Do not expose this service to an untrusted network.
